import {
  Component
} from '@angular2/core';
import defaultMember from "module-name";
import   *    as name from "module-name  ";
import   {  member }   from "  module-name";
import { member as alias } from "module-name";
import { member1 , member2 } from "module-name";
import { member1 , member2 as alias2 , member3 as alias3 } from "module-name";
import {
  Component
} from '@angular2/core';
import defaultMember from "$module-name";
import defaultMember, { member, member } from "module-name";
import defaultMember, * as name from "module-name";

import   *    as name from "module-name  "
import   {  member }   from "  module-name"
import { member as alias } from "module-name"
import { member1 , member2 } from "module-name"
import { member1 , member2 as alias2 , member3 as alias3 } from "module-name"
import {
  Component
} from '@angular2/core'
import defaultMember from "$module-name"
import defaultMember, { member, member } from "module-name"
import defaultMember, * as name from "module-name"

import "module-name";
import React from "react"
import { Field } from "redux-form"
import "module-name";

import {
    PlaneBufferGeometry,
    OctahedronGeometry,
    TorusBufferGeometry
} from '../geometries/Geometries.js';

import {
    PlaneBufferGeometry,
    OctahedronGeometry,
    TorusBufferGeometry
} from '../geometries/Geometries.js'

import("module-name/whatever.ts");
import("module-name/whatever.ts")

import { Field } from "redux-form";
import MultiContentListView from "./views/ListView";
import MultiContentAddView from "./views/AddView";
import MultiContentEditView from "./views/EditView";

import { Field } from "redux-form"
import MultiContentListView from "./views/ListView"
import MultiContentAddView from "./views/AddView"
import MultiContentEditView from "./views/EditView"


<MenuItem value="^$" primaryText="Não exibir importados" />
<MenuItem value="\\w+" primaryText="Exibir importados" />

// *Add all needed dependency to this module
// *app requires those import modules to function


/**
* 
  *Add all needed dependency to this module
  *app requires those import modules to function
  * 
**/

let modules = [];


import defaultExport from "module-name";
import * as name from "module-name";
import { export1 } from "module-name";
import { export1 as alias1 } from "module-name";
import { default as alias } from "module-name";
import { export1, export2 } from "module-name";
import { export1, export2 as alias2, /* … */ } from "module-name";
import { "string name" as alias } from "module-name";
import defaultExport, { export1, /* … */ } from "module-name";
import defaultExport, * as name from "module-name";
import "module-name";
import { "a-b" as a } from "/modules/my-module.ts";
import myDefault from "/modules/my-module.ts";
import myDefault, * as myModule from "/modules/my-module.ts";
